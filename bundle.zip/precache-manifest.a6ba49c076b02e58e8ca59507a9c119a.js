self.__precacheManifest = [
  {
    "revision": "6506a94be256299df6d0c3297b606e49",
    "url": "/static/media/party.6506a94b.jpg"
  },
  {
    "revision": "b2400d81ceeda6e3b3f3f77ecf09ac99",
    "url": "/static/media/logo.b2400d81.png"
  },
  {
    "revision": "8cf4312a415030cb49a702ea04431920",
    "url": "/static/media/discuss.8cf4312a.png"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "170bad5349b77df98b10",
    "url": "/static/js/main.4020acb1.chunk.js"
  },
  {
    "revision": "71a181d02c926838d329",
    "url": "/static/js/2.5bdbaa38.chunk.js"
  },
  {
    "revision": "170bad5349b77df98b10",
    "url": "/static/css/main.8dcc22a8.chunk.css"
  },
  {
    "revision": "71a181d02c926838d329",
    "url": "/static/css/2.073b9b51.chunk.css"
  },
  {
    "revision": "a7b45f7c22d03ed7bec27db28a0d1ddf",
    "url": "/index.html"
  }
];