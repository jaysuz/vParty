self.__precacheManifest = [
  {
    "revision": "6506a94be256299df6d0c3297b606e49",
    "url": "/static/media/party.6506a94b.jpg"
  },
  {
    "revision": "b2400d81ceeda6e3b3f3f77ecf09ac99",
    "url": "/static/media/logo.b2400d81.png"
  },
  {
    "revision": "8cf4312a415030cb49a702ea04431920",
    "url": "/static/media/discuss.8cf4312a.png"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "9eac03383a89fdc30c32",
    "url": "/static/js/main.94c62766.chunk.js"
  },
  {
    "revision": "278b8992b396fbeffc6d",
    "url": "/static/js/2.b835c287.chunk.js"
  },
  {
    "revision": "9eac03383a89fdc30c32",
    "url": "/static/css/main.c65cf934.chunk.css"
  },
  {
    "revision": "278b8992b396fbeffc6d",
    "url": "/static/css/2.073b9b51.chunk.css"
  },
  {
    "revision": "e65817abb8491f0f3bfb5eabd3d51fe3",
    "url": "/index.html"
  }
];