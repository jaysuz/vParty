self.__precacheManifest = [
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.42ac5946.js"
  },
  {
    "revision": "28d90aaa996a90eb7143",
    "url": "/static/js/main.28d90aaa.chunk.js"
  },
  {
    "revision": "147869a87a7c0313083f",
    "url": "/static/js/2.147869a8.chunk.js"
  },
  {
    "revision": "28d90aaa996a90eb7143",
    "url": "/static/css/main.4286f70c.chunk.css"
  },
  {
    "revision": "147869a87a7c0313083f",
    "url": "/static/css/2.073b9b51.chunk.css"
  },
  {
    "revision": "0d784fdfa6a8d3c7ababf034bf4d9268",
    "url": "/index.html"
  }
];