self.__precacheManifest = [
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  },
  {
    "revision": "6506a94be256299df6d0c3297b606e49",
    "url": "/static/media/party.6506a94b.jpg"
  },
  {
    "revision": "b2400d81ceeda6e3b3f3f77ecf09ac99",
    "url": "/static/media/logo.b2400d81.png"
  },
  {
    "revision": "8cf4312a415030cb49a702ea04431920",
    "url": "/static/media/discuss.8cf4312a.png"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "56d22466826b4637b44b",
    "url": "/static/js/main.ecf8801d.chunk.js"
  },
  {
    "revision": "d277a8b6af2fdcc36cfe",
    "url": "/static/js/2.2f418d75.chunk.js"
  },
  {
    "revision": "56d22466826b4637b44b",
    "url": "/static/css/main.1d9fe150.chunk.css"
  },
  {
    "revision": "d277a8b6af2fdcc36cfe",
    "url": "/static/css/2.073b9b51.chunk.css"
  },
  {
    "revision": "1c0eb6070ddbf0fb0025054364db83dd",
    "url": "/index.html"
  }
];