self.__precacheManifest = [
  {
    "revision": "6506a94be256299df6d0c3297b606e49",
    "url": "/static/media/party.6506a94b.jpg"
  },
  {
    "revision": "b2400d81ceeda6e3b3f3f77ecf09ac99",
    "url": "/static/media/logo.b2400d81.png"
  },
  {
    "revision": "8cf4312a415030cb49a702ea04431920",
    "url": "/static/media/discuss.8cf4312a.png"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "f25cdbbfec8fc2b37db8",
    "url": "/static/js/main.55b183ec.chunk.js"
  },
  {
    "revision": "d6a386fe669d4eb61ec4",
    "url": "/static/js/2.4b42f218.chunk.js"
  },
  {
    "revision": "f25cdbbfec8fc2b37db8",
    "url": "/static/css/main.2c708523.chunk.css"
  },
  {
    "revision": "d6a386fe669d4eb61ec4",
    "url": "/static/css/2.073b9b51.chunk.css"
  },
  {
    "revision": "65453b3df34bc487bd8d697b90c1c314",
    "url": "/index.html"
  }
];