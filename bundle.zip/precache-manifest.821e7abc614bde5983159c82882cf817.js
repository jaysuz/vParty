self.__precacheManifest = [
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.42ac5946.js"
  },
  {
    "revision": "c609f779dea294df5cd5",
    "url": "/static/js/main.c609f779.chunk.js"
  },
  {
    "revision": "e25b472d00072bcda2b5",
    "url": "/static/js/2.e25b472d.chunk.js"
  },
  {
    "revision": "c609f779dea294df5cd5",
    "url": "/static/css/main.4286f70c.chunk.css"
  },
  {
    "revision": "e25b472d00072bcda2b5",
    "url": "/static/css/2.073b9b51.chunk.css"
  },
  {
    "revision": "76fde030cc27bee34d6e7a86eac1b04f",
    "url": "/index.html"
  }
];