self.__precacheManifest = [
  {
    "revision": "6506a94be256299df6d0c3297b606e49",
    "url": "/static/media/party.6506a94b.jpg"
  },
  {
    "revision": "b2400d81ceeda6e3b3f3f77ecf09ac99",
    "url": "/static/media/logo.b2400d81.png"
  },
  {
    "revision": "8cf4312a415030cb49a702ea04431920",
    "url": "/static/media/discuss.8cf4312a.png"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "1278d1b79f546d5db85c",
    "url": "/static/js/main.5c7b5177.chunk.js"
  },
  {
    "revision": "278b8992b396fbeffc6d",
    "url": "/static/js/2.b835c287.chunk.js"
  },
  {
    "revision": "1278d1b79f546d5db85c",
    "url": "/static/css/main.b55a075e.chunk.css"
  },
  {
    "revision": "278b8992b396fbeffc6d",
    "url": "/static/css/2.073b9b51.chunk.css"
  },
  {
    "revision": "546873e135260c0c64e0a2111aa6463b",
    "url": "/index.html"
  }
];